package samples.math;

public class Math {
    public float add(float a, float b) {
        return a+b;
    }
}
