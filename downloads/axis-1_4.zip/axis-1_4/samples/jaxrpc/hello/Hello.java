/**
 * Hello.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis WSDL2Java emitter.
 */

package samples.jaxrpc.hello;

public interface Hello extends java.rmi.Remote {
    public java.lang.String sayHello(java.lang.String string1) throws java.rmi.RemoteException;
}
