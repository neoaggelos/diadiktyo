/**
 * LoggingFacilitySoapBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis #axisVersion# #today# WSDL2Java emitter.
 */

package org.apache.axis.wsi.scm.logging;

public class LoggingFacilitySoapBindingImpl implements org.apache.axis.wsi.scm.logging.LoggingFacilityLogPortType{
    public void logEvent(org.apache.axis.wsi.scm.logging.LogEventRequestType document) throws java.rmi.RemoteException {
    }

    public org.apache.axis.wsi.scm.logging.GetEventsResponseType getEvents(org.apache.axis.wsi.scm.logging.GetEventsRequestType document) throws java.rmi.RemoteException, org.apache.axis.wsi.scm.logging.GetEventsFaultType {
        return null;
    }

}
