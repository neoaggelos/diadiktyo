/**
 * WarehouseSoapBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis #axisVersion# #today# WSDL2Java emitter.
 */

package org.apache.axis.wsi.scm.warehouse;

public class WarehouseSoapBindingImplA implements org.apache.axis.wsi.scm.warehouse.WarehouseShipmentsPortType{
    public org.apache.axis.wsi.scm.warehouse.ItemShippingStatusList shipGoods(org.apache.axis.wsi.scm.warehouse.ItemList itemList, org.apache.axis.types.NormalizedString customer, org.apache.axis.wsi.scm.configuration.ConfigurationType configurationHeader) throws java.rmi.RemoteException, org.apache.axis.wsi.scm.configuration.ConfigurationFaultType {
        return null;
    }

}
