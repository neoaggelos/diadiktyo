package org.apache.axis.wsi.scm.manufacturer;
/**
 * ManufacturerSoapBindingImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis #axisVersion# #today# WSDL2Java emitter.
 */

public class ManufacturerSoapBindingImplB implements org.apache.axis.wsi.scm.manufacturer.ManufacturerPortType{
	public boolean submitPO(org.apache.axis.wsi.scm.manufacturer.po.PurchOrdType purchaseOrder, org.apache.axis.wsi.scm.configuration.ConfigurationType configurationHeader, org.apache.axis.wsi.scm.manufacturer.callback.StartHeaderType startHeader) throws java.rmi.RemoteException, org.apache.axis.wsi.scm.configuration.ConfigurationFaultType, org.apache.axis.wsi.scm.manufacturer.po.SubmitPOFaultType {
		return false;
    }

}
